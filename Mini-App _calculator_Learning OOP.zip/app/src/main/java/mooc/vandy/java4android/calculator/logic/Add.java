package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Add operation.
 */
public class Add { //super class
    // TODO -- start your code here
    private int numOne; //stores the value of the first operand
    private int numTwo; //stores the value of the second operand
    private String result; //stores the result of operation

    public Add(int numOne, int numTwo) // constructor of the super class
    {
       setNums(numOne, numTwo);
    }

    public void setNums(int numOne, int numTwo) //setter for operands
    {
        this.numOne = numOne;
        this.numTwo = numTwo;
    }

    public void setResult(String result) //setter for result
    {
        this.result = result;
    }

    public int getNumOne() //getter for the first operand
    {
        return this.numOne;
    }

    public int getNumTwo() //getter for the second operand
    {
        return this.numTwo;
    }

    public String getResult() //getter for the result of operation
    {
        return this.result;
    }

    public int calculate(int numOne, int numTwo) // calculation method
    {
        int res = numOne + numTwo;
        setResult(String.valueOf(res)); //set the private fielf result
        return res;
    }

    @Override
    public String toString() //overridden method to print the object. Universal for the super and sub classes
    {
        return getResult();
    }
}
