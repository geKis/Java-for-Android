package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Divide operation.
 */
public class Divide extends Add {
    // TODO -- start your code here

    public Divide(int numOne, int numTwo) // constructor of the subclass
    {
        super(numOne, numTwo); //call the base class constructor
    }

    @Override
    public int calculate(int numOne, int numTwo) //overridden calculation method for division
    {
        String res;
        try // processing exceptions. Check for division by zero
        {
            int div = numOne / numTwo;
            int mod = numOne % numTwo;
            res = div + " R: " + mod; // special output format
            setResult(res); //initialize the result variable
            return div; //returns the result of integer division. Not used in this application.
        }
        catch (ArithmeticException e) //handling exception
        {
            res = "Error! Division by 0! Please fill in correct field Value Two";
            setResult(res);
            return 0;
        }
    }

}
