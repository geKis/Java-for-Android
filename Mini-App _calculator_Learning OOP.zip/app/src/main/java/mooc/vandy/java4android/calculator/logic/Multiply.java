package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Multiply operation.
 */
public class Multiply extends Add {
    // TODO -- start your code here

    public Multiply(int numOne, int numTwo) // constructor of the subclass
    {
        super(numOne, numTwo); //call the base class constructor
    }

    @Override
    public int calculate(int numOne, int numTwo) //overridden calculation method for multiplication
    {
        int res = numOne * numTwo;
        setResult(String.valueOf(res));
        return res;
    }
}
