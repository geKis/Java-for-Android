package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Subtract operation.
 */
public class Subtract extends Add {
    // TODO -- start your code here

    public Subtract(int numOne, int numTwo) // constructor of the subclass
    {
        super(numOne, numTwo); //call the base class constructor
    }

    @Override
    public int calculate(int numOne, int numTwo) // overridden calculation method for multiplication
    {
        int res = numOne - numTwo;
        setResult(String.valueOf(res));
        return res;
    }
}

